﻿using EntityFramework2._0.app.Web.Code;
using EntityFramework2._0.app.Web.Code.ADO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EntityFramework2._0
{
    public partial class DestinationWeb : System.Web.UI.Page
    {

        private CategoriaADO ado = new CategoriaADO();

        private void CargarTabla()
        {

            GridView1.DataSource = ado.GetCategorias();
            GridView1.DataBind();

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            CargarTabla();
        }

        protected void btnADD_Click(object sender, EventArgs e)
        {
            
            //Guardar imagen en archivos
            string saveDir = @"\Imagenes\";
            string appPath = Request.PhysicalApplicationPath;
            string savePath = appPath + saveDir +
                Server.HtmlEncode(FileUpload1.FileName);
            FileUpload1.SaveAs(savePath);
            savePath = txtName.Text;
            //---------------------------------------------------
            //Guardar en la base de datos
            Places nueva = new Places();
            nueva.NAME = txtName.Text.ToUpper();
            nueva.PHOTO = FileUpload1.FileName;
            nueva.DESCRIPTION = txtDescription.Text.ToUpper();

            int i = ado.agregarCategoria(nueva);
            //----------------------------------------------------
        }
    }
}