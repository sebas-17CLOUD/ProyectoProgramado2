﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EntityFramework2._0.app.Web.Code.ADO
{
    public class CategoriaADO
    {
        private DestinationPlacesEntities contexto = new DestinationPlacesEntities();

        public CategoriaADO() 
        { 
        
        }

        public int agregarCategoria(Places nueva)
        {
            contexto.Places.Add(nueva);
            return contexto.SaveChanges();

        }

        public Places buscarCategoria(int codigo) 
        { 
            return contexto.Places.Find(codigo);
        }

        public List<Places> GetCategorias() 
        {
            return contexto.Places.ToList();
        }

        public int eliminarCategria(int codigo)
        {
            Places c = contexto.Places.Find(codigo);
            contexto.Places.Remove(c);
            return contexto.SaveChanges();
        }

    }
}